package com.example.cameratest;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.Image;
import android.util.Base64;
import android.util.Log;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;


public class PhotoSend implements Runnable{
    //we are only sending the image for now
    private Socket socket;
    private DataOutputStream os;
    private byte[] imageData;
    private ImageView capturedImageView;
    private MainActivity mainActivity;

    public PhotoSend(String serverIP, ImageView capturedImageView, MainActivity mainActivity){
        this.mainActivity = mainActivity;
        this.capturedImageView = capturedImageView;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    //add your server ip
                    socket = new Socket(serverIP, 4444);
                    os = new DataOutputStream( socket.getOutputStream());

                }catch(IOException e){
                    Log.i("CONNECTION STATUS" ,"COULD NOT CONNECT");
                    e.printStackTrace();
                    closeEveryThing(socket);
                }
            }
        }).start();
    }

    public void run(){
        Bitmap original_bmp  = BitmapFactory.decodeByteArray(imageData, 0, imageData.length); //this is immutable

        //binarize the bitmap
        Bitmap binarized_bmp = original_bmp.copy(Bitmap.Config.RGB_565, true);
        for(int i = 0;  i < binarized_bmp.getWidth(); i++){
            for(int j = 0; j < binarized_bmp.getHeight(); j++){
                int pixel = binarized_bmp.getPixel(i, j);
                if(determineIsBlack(pixel)){
                    binarized_bmp.setPixel(i, j, Color.BLACK);
                }else{
                    binarized_bmp.setPixel(i, j, Color.WHITE);
                }
            }
        }

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        binarized_bmp.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
        String encodedImage = Base64.encodeToString(byteArrayOutputStream.toByteArray(), Base64.DEFAULT);
        Log.i("ENCODED IMAGE", encodedImage.length() + "");
        ArrayList<String> partitionedEncodedIMG = new ArrayList<>(); //need to partition and send each string in a different thread
        int start_index = 0;
        int end_index = 2000;
        while(start_index < encodedImage.length()){
            if(end_index  < encodedImage.length()){
                partitionedEncodedIMG.add(encodedImage.substring(start_index, end_index));
            }else{
                partitionedEncodedIMG.add(encodedImage.substring(start_index));
            }
            start_index = end_index;
            end_index += 2000;
        }

        //FOR DEBUGGING
        /*mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                capturedImageView.setImageBitmap(binarized_bmp);
            }
        });*/
        //FOR DEBUGGING -> SEE IF ARRAYLIST WORKS CORRECTLY
        //int charcount = 0;
        //for(String temp : partitionedEncodedIMG){
        //    charcount += temp.length();
        //}
        //Log.i("ARRAYLIST", charcount + "");

        //start sending index by index
        int index_of_partitionedEncodedIMG = 0;
        while(index_of_partitionedEncodedIMG <= partitionedEncodedIMG.size()){
            //put this thread to sleep just in case server misses a string
            try{
                Thread.sleep(5);
            }catch(InterruptedException e){
                e.printStackTrace();
            }
            int finalIndex_of_partitionedEncodedIMG = index_of_partitionedEncodedIMG; //effectively final arraylist index
            index_of_partitionedEncodedIMG++;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try{
                        if(finalIndex_of_partitionedEncodedIMG < partitionedEncodedIMG.size()) {
                            os.writeUTF(partitionedEncodedIMG.get(finalIndex_of_partitionedEncodedIMG));
                            os.flush();
                        }
                    }catch (IOException e){
                        e.printStackTrace();
                    }
                }
            }).start();
        }
        try{
            os.writeUTF("@"); //ending transmission character
            os.flush();
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    private boolean determineIsBlack(int pixel){
        int alpha = Color.alpha(pixel);
        int redValue = Color.red(pixel);
        int greenValue = Color.green(pixel);
        int blueValue = Color.blue(pixel);

        //if transparent set to white
        if(alpha == 0x00){
            return true;
        }else{
            //see the distance as a function in 4 dimensions
            double distanceFromWhite = Math.sqrt(Math.pow(0xff - redValue, 2) + Math.pow(0xff - blueValue, 2) + Math.pow(0xff - greenValue, 2));
            double distanceFromBlack = Math.sqrt(Math.pow(0x00 - redValue, 2) + Math.pow(0x00 - blueValue, 2) + Math.pow(0x00 - greenValue, 2));
            return distanceFromBlack < distanceFromWhite? true : false;
        }
    }


    public void setByteArray(byte[] bytes){

        imageData = bytes;
    }

    public void closeEveryThing(Socket socket) {
        try {

            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
